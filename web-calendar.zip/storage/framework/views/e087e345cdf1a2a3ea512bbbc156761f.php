<?php
    $inputObj = new stdClass();
    $inputObj->url = url('user/monthly-calendar');
    $inputObj->params = 'id='.$calendarId;
    $encLink = Common::encryptLink($inputObj);

    $inputObjM = new stdClass();
    $inputObjM->url = url('user/three-monthly-calendar');
    $inputObjM->params = 'id='.$calendarId;
    $encLinkM = Common::encryptLink($inputObjM);

    $inputObjY = new stdClass();
    $inputObjY->url = url('user/yearly-calendar');
    $inputObjY->params = 'id='.$calendarId;
    $encLinkY = Common::encryptLink($inputObjY);

?>

<?php if(Route::current()->getName()=="u-monthly-calendar"): ?>
    <a  href="<?php echo e($encLink); ?>" class="text-white bg-blue-500 hover:bg-blue-600 focus:ring-4 focus:ring-blue-300 font-medium rounded px-3 py-2 mr-2 mb-2 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none dark:focus:ring-blue-700">Monthly</a>
<?php else: ?>
    <a  href="<?php echo e($encLink); ?>" class="px-5 py-2 mr-2 mb-2 font-medium text-gray-900 focus:outline-none bg-white rounded border border-gray-200 hover:bg-gray-100 hover:text-blue-500 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Monthly</a>
<?php endif; ?>

<?php if(Route::current()->getName()=="u-three-monthly-calendar"): ?>
    <a  href="<?php echo e($encLinkM); ?>" class="text-white bg-blue-500 hover:bg-blue-600 focus:ring-4 focus:ring-blue-300 font-medium rounded px-3 py-2 mr-2 mb-2 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none dark:focus:ring-blue-700">3 Months</a>
<?php else: ?>
    <a  href="<?php echo e($encLinkM); ?>" class="px-5 py-2 mr-2 mb-2 font-medium text-gray-900 focus:outline-none bg-white rounded border border-gray-200 hover:bg-gray-100 hover:text-blue-500 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">3 Months</a>
<?php endif; ?>

<?php if(Route::current()->getName()=="u-yearly-calendar"): ?>
    <a  href="<?php echo e($encLinkY); ?>" class="text-white bg-blue-500 hover:bg-blue-600 focus:ring-4 focus:ring-blue-300 font-medium rounded px-3 py-2 mr-2 mb-2 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none dark:focus:ring-blue-700">Yearly</a>
<?php else: ?>
    <a  href="<?php echo e($encLinkY); ?>" class="px-5 py-2 mr-2 mb-2 font-medium text-gray-900 focus:outline-none bg-white rounded border border-gray-200 hover:bg-gray-100 hover:text-blue-500 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Yearly</a>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\web-calendar\resources\views/user/dashboard/top_menu.blade.php ENDPATH**/ ?>