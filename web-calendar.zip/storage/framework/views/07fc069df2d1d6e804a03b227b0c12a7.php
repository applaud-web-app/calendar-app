<?php $__env->startSection('section'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/iziToast.min.css')); ?>">
<?php $__env->stopPush(); ?>
<section class="relative content-body">
    <div class="container mx-auto ">
        <div>
            <?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="flex items-center justify-between flex-wrap mb-5">
            <div class="items-center ">
                <h1 class="md:text-3xl text-2xl md:mb-0 mb-3 block dark:text-slate-100"><?php echo e($calendarD->calendar_name); ?></h1>

            </div>
           
        </div>
       

        <div class="w-full mb-5">
            <?php echo $__env->make('user.dashboard.top_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="card h-full" id="calendar_pst">
            <div class="card-header flex justify-between space-x-1">
                <h4 class="card-title"><?php echo e($monthName); ?></h4>
                <div class="space-x-1 whitespace-nowrap">
                    <button type="button" onclick="getMonthData('<?php echo e($prevDate); ?>')" class="text-white bg-blue-500 hover:bg-blue-600 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-3 py-2 text-center inline-flex items-center  dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        <i class="fas fa-arrow-left "></i>  
                    </button>
                    <button type="button" onclick="getMonthData('<?php echo e($nextDate); ?>')" class="text-white bg-blue-500 hover:bg-blue-600 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded text-sm px-3 py-2 text-center inline-flex items-center  dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        <i class="fas fa-arrow-right "></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="relative overflow-x-auto  sm:rounded">
                        
                    <table class="w-full text-sm text-left text-gray-900 dark:text-gray-400 border border-gray-400">
                        <thead class="text-xs text-gray-100 uppercase bg-gray-800 dark:bg-slate-700 ">
                            <tr class="align-top">
                                <th scope="col" class="px-3 py-4">
                                    Date
                                </th>
                                <th scope="col" class="px-3 py-4">
                                    Event
                                </th>
                                <th scope="col" class="px-3 py-4">
                                    Time
                                </th>
                              
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $monthDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($dateEvents[$item->date])): ?>
                                    <?php $__currentLoopData = $dateEvents[$item->date]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="dark:bg-slate-800 border-b  dark:border-slate-700  border-gray-400 dark:hover:bg-slate-900/20 align-top" style="background: <?php echo $val->color_code; ?>;">
                                            <td class="px-3 py-4">
                                                <?php echo e($item->format_date); ?>

                                            </td>
                                            <td scope="row" class="px-3 py-4 font-medium text-gray-900 dark:text-white ">
                                            
                                                <p class=" font-medium text-black truncate dark:text-white">
                                                    <?php echo e($val->event_title); ?>

                                                </p>
                                            
                                            </td>
                                            <td class="px-3 py-4">
                                                <p class="text-sm text-gray-600 truncate dark:text-gray-400">
                                                    <i class="fa-solid fa-clock"></i> <?php echo e(Common::timeFormatGl($val->event_time)); ?>

                                                </p>
                                            
                                            </td>

                                        </tr>            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="bg-white-500 border-b dark:bg-gray-800 dark:border-slate-700  border-gray-400 dark:hover:bg-slate-900/20 align-top">
                                        <td class="p-4">
                                        <?php echo e($item->format_date); ?>

                                        </td>
                                        <td scope="row" class="px-3 py-4 font-medium text-gray-900 dark:text-white ">
                                            <p class=" font-medium text-black truncate dark:text-white"></p>
                                        </td>
                                        <td class="px-3 py-4">
                                            <p class="text-sm text-gray-600 truncate dark:text-gray-400"></p>
                                        </td>
                                        
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          

                                         
                        </tbody>
                    </table>
                </div>                            
            </div><!--end card-body-->
        </div>

    </div>
</section>


    
<?php
    $inputObj = new stdClass();
    $inputObj->url = url('user/store-calendar-event');
    $inputObj->params = 'id='.$calendarId;
    $encLink = Common::encryptLink($inputObj);
   
    $inputObjPP = new stdClass();
    $inputObjPP->url = url('user/get-calendar-month-data');
    $inputObjPP->params = 'id='.$calendarId;
    $postLink = Common::encryptLink($inputObjPP);
?>
<form action="<?php echo e($encLink); ?>" class="modal fade" id="addEventModal" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal-dialog modal-dialog-center">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title mt-0" id="staticBackdropLabel1">Add Event</h6>
                <button type="button" class="btn-close" aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
            </div>
            <div class="modal-body" id="modalBody">
            
            </div>
            <div class="modal-footer">
              
                <button type="submit" id="submit_btn" class="text-white bg-blue-500 hover:bg-blue-600  font-medium rounded block w-full px-3 py-2 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none  my-auto">Save Changes</button>
            </div>
        </div>
    </div>
</form>

<div id="editEventModal" class="modal fade">

</div>

<div class="modal-overlay"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/js/iziToast.min.js')); ?>"></script>
   

    <script>
        async function getMonthData(date){
            const response = await fetch('<?php echo e($postLink); ?>',{
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({'date':date})
            });
            const data = await response.text();
            document.getElementById('calendar_pst').innerHTML = data;
        }
    </script>

<?php $__env->stopPush(); ?>




<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\web-calendar\resources\views/user/dashboard/monthly-calendar.blade.php ENDPATH**/ ?>