<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Calendar App</title>
  <meta content="Tailwind Multipurpose Admin & Dashboard Template" name="description" />
  <meta content="" name="author" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />

  <!-- App favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" />
  

  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

  <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body data-layout-mode="light"
  class="bg-gray-50 dark:bg-gray-900 ">

  
  <header class="sticky top-0 z-40 header_area">

    <nav class="border-gray-200 bg-[#091734] px-2.5 py-2.5 shadow-sm dark:bg-slate-800 sm:px-4 block print:hidden">
      <div class="container mx-0 flex flex-wrap items-center lg:mx-auto">
        <div class="flex items-center">
          <a href="<?php echo e(url('/')); ?>" class="flex items-center outline-none">

            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="" class="ml-2 block h-12 md:h-20  w-auto" />
          </a>
        </div>


        <div class="order-1 ml-auto flex items-center md:order-2">

          

         
            
          <?php if(!Auth::check()): ?>
          <div class="relative mr-2 hidden lg:mr-4 lg:block">
            <a href="<?php echo e(url('/')); ?>" class="px-3 py-2  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded border border-gray-200 hover:bg-gray-100 hover:text-blue-500 focus:z-10 focus:ring-2 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"><i class="fa-solid fa-right-to-bracket pr-1"></i>Login</a>
          </div>
          <?php endif; ?>
          <div class="mr-2 lg:mr-0 dropdown relative">
            <?php if(Auth::check()): ?>
              <button type="button"
                class="dropdown-toggle flex items-center rounded-full text-sm focus:bg-none focus:ring-0 dark:focus:ring-0 md:mr-0"
                id="user-profile" aria-expanded="false" data-dropdown-toggle="navUserdata">
                <img class="h-8 w-8 rounded-full" src="<?php echo e(asset('assets/images/users/avatar-1.jpg')); ?>" alt="user photo" />
                <span class="ml-2 hidden text-left xl:block">
                  <span class="block font-medium text-gray-50"><?php echo e(Auth::user()->name); ?> <i class="fas fa-chevron-down text-xs"></i>          </span>
                  <span class=" block text-sm font-medium text-gray-200"><?php echo e(Auth::user()->email); ?></span>
                  
                </span>
              </button>
            

              <div
                class="dropdown-menu  z-50 my-1 hidden list-none divide-y divide-gray-100 rounded border-slate-700 md:border-white text-base shadow dark:divide-gray-600 bg-white dark:bg-slate-800"
                id="navUserdata">
                <div class="py-3 px-4">
                  <span class="block text-sm font-medium text-gray-900 dark:text-white"><?php echo e(Auth::user()->name); ?></span>
                  <span class="block truncate text-sm font-normal text-gray-500 dark:text-gray-400"><?php echo e(Auth::user()->email); ?></span>
                </div>
                <ul class="py-1" aria-labelledby="navUserdata">
                  <li>
                    <a href="<?php echo e(url('my-profile')); ?>"
                      class="block py-2 px-4 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-900/20 dark:hover:text-white">Profile</a>
                  </li>
                  <?php if(Auth::user()->u_type==1): ?>
                    <li>
                      <a href="<?php echo e(url('admin/enquiries')); ?>"
                        class="block py-2 px-4 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-900/20 dark:hover:text-white">Enquiries</a>
                    </li>
                  <?php endif; ?>
                  <li>
                    <a href="<?php echo e(route('logout')); ?>"
                      class="block py-2 px-4 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-900/20 dark:hover:text-white">Sign
                      out</a>
                  </li>
                </ul>
              </div>
            <?php endif; ?>
          </div>

         
        </div>
      </div>
    </nav>

  </header>

  

  <?php echo $__env->yieldContent('section'); ?>

  
  

<footer class="bg-[#1282bf] w-full footer_area">
  <div class="container mx-auto p-3">
    <div class="sm:flex sm:items-center sm:justify-between ">
      <div class="flex my-1 justify-center sm:mt-0 space-x-3">
        <a href="#" class="h-8 w-8 text-center leading-8 bg-white text-blue-500 hover:text-blue-600 border rounded-full border-gray-100 dark:hover:text-white ">
          <i class="fa-brands fa-facebook-f"></i>
           
        </a>
        <a href="#" class="h-8 w-8 text-center leading-8 bg-white text-blue-500 hover:text-blue-600 border rounded-full border-gray-100 dark:hover:text-white ">
          <i class="fa-brands fa-instagram"></i>
          
        </a>
        <a href="#" class="h-8 w-8 text-center leading-8 bg-white text-blue-500 hover:text-blue-600 border rounded-full border-gray-100 dark:hover:text-white ">
          <i class="fa-brands fa-twitter"></i>
           
        </a>
        <a href="#" class="h-8 w-8 text-center leading-8 bg-white text-blue-500 hover:text-blue-600 border rounded-full border-gray-100 dark:hover:text-white ">
          <i class="fa-brands fa-linkedin-in "></i>
           
        </a>
      
    </div>
      <ul class="flex flex-wrap items-center justify-center  text-sm font-medium text-gray-100 sm:mb-0 my-1 ">
          <li>
              <a href="<?php echo e(url('terms-and-condition')); ?>" class="hover:underline me-3 md:me-6">Terms Of Use</a>
          </li>
          <li>
              <a href="<?php echo e(url('privacy-policy')); ?>" class="hover:underline me-3 md:me-6">Privacy Notice</a>
          </li>
          <li>
              <a href="<?php echo e(url('contact-us')); ?>" class="hover:underline me-3 md:me-6">Contact Us</a>
          </li>
          
      </ul>
    </div>
    <hr class="my-2 border-gray-200 sm:mx-auto  lg:my-5" />
    <span class="block text-sm text-white text-center ">©  <script>
      document.write(new Date().getFullYear());
    </script> <a href="https://applaudwebmedia.com/" class="hover:underline">Applaud Web Media Pvt. Ltd.</a> All Rights Reserved.</span>
  </div>
  
</footer>




  <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/pages/components.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>


  <?php echo $__env->yieldPushContent('scripts'); ?>

  <script>
 
    
        var h_height = document.querySelector('.header_area').offsetHeight;
        var f_height = document.querySelector('.footer_area').offsetHeight;
        document.querySelector('.content-body').style.minHeight = window.innerHeight - (h_height + f_height) + 'px';
    
   
  </script>

</body>

</html><?php /**PATH D:\xampp\htdocs\web-calendar\resources\views/layout/master.blade.php ENDPATH**/ ?>